export const dynamic = "force-dynamic";

export default function LoginPage() {
  return (
    <article>
      <h1>Login do Admin</h1>
      <p className="meta">Senha vem da variável <code>ADMIN_PASSWORD</code>.</p>
      <form action="/admin/login" method="post" style={{marginTop:14, display:"grid", gap:10, maxWidth:420}}>
        <input className="input" type="password" name="password" placeholder="Senha do admin" required />
        <button className="btn" type="submit">Entrar</button>
      </form>
    </article>
  );
}
