import { prisma } from "@/lib/prisma";
import { RecipeCard } from "@/components/RecipeCard";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function CategoryPage({ params }: { params: { category: string } }) {
  const category = decodeURIComponent(params.category);
  const recipes = await prisma.recipe.findMany({
    where: { category },
    orderBy: { publishedAt: "desc" },
    take: 60,
  });

  return (
    <>
      <div className="hero">
        <h1>{category}</h1>
        <p>{recipes.length} receitas nesta categoria.</p>
        <div className="kpis">
          <Link className="pill" href="/">← Home</Link>
          <Link className="pill" href="/categories">Todas as categorias</Link>
        </div>
      </div>
      <div className="grid">
        {recipes.map((r) => (
          <RecipeCard key={r.id} title={r.title} slug={r.slug} category={r.category} publishedAt={r.publishedAt.toISOString()} />
        ))}
      </div>
    </>
  );
}
