import { NextResponse } from "next/server";
import { clearAdminCookie } from "@/lib/auth";

export async function POST(req: Request) {
  const res = NextResponse.redirect(new URL("/admin", req.url));
  res.headers.set("Set-Cookie", clearAdminCookie());
  return res;
}
