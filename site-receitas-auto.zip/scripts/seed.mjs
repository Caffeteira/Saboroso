import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

const samples = [
  {
    title: "Macarrão alho e manteiga (5 ingredientes)",
    category: "Massa",
    slug: "macarrao-alho-e-manteiga-5-ingredientes",
    ingredients: ["macarrão", "alho", "manteiga", "parmesão", "pimenta-do-reino"],
    steps: [
      "Cozinhe o macarrão até ficar al dente e reserve um pouco da água do cozimento.",
      "Doure o alho na manteiga sem queimar.",
      "Misture o macarrão na panela e ajuste com um pouco da água reservada.",
      "Finalize com parmesão e pimenta.",
      "Sirva na hora."
    ]
  },
  {
    title: "Frango mel e shoyu rápido",
    category: "Frango",
    slug: "frango-mel-e-shoyu-rapido",
    ingredients: ["frango", "mel", "shoyu", "alho", "azeite"],
    steps: [
      "Tempere o frango com sal (opcional) e alho.",
      "Sele o frango no azeite até dourar.",
      "Junte mel e shoyu e deixe reduzir.",
      "Vire as peças para envolver no molho.",
      "Sirva com arroz ou legumes."
    ]
  }
];

for (const r of samples) {
  await prisma.recipe.upsert({
    where: { slug: r.slug },
    update: {},
    create: {
      title: r.title,
      category: r.category,
      slug: r.slug,
      ingredients: JSON.stringify(r.ingredients),
      steps: JSON.stringify(r.steps),
    }
  });
}

console.log("Seed concluído.");
await prisma.$disconnect();
