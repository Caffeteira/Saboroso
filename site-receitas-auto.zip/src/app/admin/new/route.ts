import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAdmin } from "@/lib/auth";
import { slugify } from "@/lib/text";

export async function POST(req: Request) {
  if (!isAdmin()) return NextResponse.redirect(new URL("/admin/login", req.url));

  const form = await req.formData();
  const title = String(form.get("title") ?? "").trim();
  const category = String(form.get("category") ?? "").trim();
  const ingredientsRaw = String(form.get("ingredients") ?? "");
  const stepsRaw = String(form.get("steps") ?? "");
  const imageUrl = String(form.get("imageUrl") ?? "").trim() || null;

  const ingredients = ingredientsRaw.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  const steps = stepsRaw.split(/\r?\n/).map(s => s.trim()).filter(Boolean);

  let baseSlug = slugify(title);
  if (!baseSlug) baseSlug = "receita";
  let slug = baseSlug;

  // ensure unique
  for (let i = 1; i < 50; i++) {
    const exists = await prisma.recipe.findUnique({ where: { slug } });
    if (!exists) break;
    slug = `${baseSlug}-${i}`;
  }

  const created = await prisma.recipe.create({
    data: {
      title,
      category,
      slug,
      ingredients: JSON.stringify(ingredients),
      steps: JSON.stringify(steps),
      imageUrl,
    },
  });

  return NextResponse.redirect(new URL(`/recipe/${created.slug}`, req.url));
}
