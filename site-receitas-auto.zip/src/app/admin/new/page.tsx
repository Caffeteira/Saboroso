import { isAdmin } from "@/lib/auth";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default function NewRecipePage() {
  if (!isAdmin()) redirect("/admin/login");

  return (
    <article>
      <h1>Criar receita</h1>
      <p className="meta">Cria um post manualmente (bom pra você ajustar qualidade além do automático).</p>

      <form action="/admin/new" method="post" style={{marginTop:14, display:"grid", gap:10}}>
        <input className="input" name="title" placeholder="Título (ex: Macarrão alho e óleo cremoso)" required />
        <input className="input" name="category" placeholder="Categoria (ex: Massa, Frango, Doces)" required />
        <textarea className="input" name="ingredients" placeholder="Ingredientes (1 por linha)" rows={6} required />
        <textarea className="input" name="steps" placeholder="Modo de preparo (1 passo por linha)" rows={8} required />
        <input className="input" name="imageUrl" placeholder="Imagem (URL opcional)" />
        <button className="btn" type="submit">Publicar</button>
      </form>
    </article>
  );
}
