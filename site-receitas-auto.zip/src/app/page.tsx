import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { RecipeCard } from "@/components/RecipeCard";

export const dynamic = "force-dynamic";

export default async function Home({
  searchParams,
}: {
  searchParams?: { q?: string; cat?: string };
}) {
  const q = searchParams?.q?.trim();
  const cat = searchParams?.cat?.trim();

  const where: any = {};
  if (q) where.title = { contains: q, mode: "insensitive" };
  if (cat) where.category = { equals: cat };

  const [recipes, total] = await Promise.all([
    prisma.recipe.findMany({
      where,
      orderBy: { publishedAt: "desc" },
      take: 24,
    }),
    prisma.recipe.count(),
  ]);

  const categories = await prisma.recipe.groupBy({
    by: ["category"],
    _count: { category: true },
    orderBy: { _count: { category: "desc" } },
    take: 8,
  });

  return (
    <>
      <div className="hero">
        <h1>Receitas novas todos os dias 🍳</h1>
        <p>
          Este site está pronto pra postar receitas automaticamente. Você pode usar gerador interno (demo) ou ligar uma API/IA.
        </p>
        <div className="kpis">
          <span className="pill">Receitas no banco: <b>{total}</b></span>
          <span className="pill">Atualizado: <b>{new Date().toLocaleString("pt-BR")}</b></span>
        </div>

        <form className="search" action="/" method="get">
          <input className="input" name="q" placeholder="Buscar receita (ex: frango, massa, bolo)..." defaultValue={q ?? ""} />
          <button className="btn" type="submit">Buscar</button>
        </form>

        <div className="kpis">
          {categories.map((c) => (
            <Link
              key={c.category}
              className="pill"
              href={`/?cat=${encodeURIComponent(c.category)}`}
              title="Filtrar por categoria"
            >
              {c.category} ({c._count.category})
            </Link>
          ))}
          <Link className="pill" href="/categories">Ver todas →</Link>
        </div>
      </div>

      <div className="grid">
        {recipes.map((r) => (
          <RecipeCard
            key={r.id}
            title={r.title}
            slug={r.slug}
            category={r.category}
            publishedAt={r.publishedAt.toISOString()}
          />
        ))}
      </div>
    </>
  );
}
