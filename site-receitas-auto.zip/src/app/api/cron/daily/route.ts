import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/text";

type GenRecipe = {
  title: string;
  category: string;
  ingredients: string[];
  steps: string[];
};

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function generateRecipe(): GenRecipe {
  const categories = ["Massa", "Frango", "Carne", "Peixe", "Vegetariano", "Café da manhã", "Doces", "Lanches", "Sopas"];
  const bases = [
    { t: "Macarrão cremoso de {a}", c: "Massa" },
    { t: "Frango rápido com {a}", c: "Frango" },
    { t: "Bolo simples de {a}", c: "Doces" },
    { t: "Sanduíche quente de {a}", c: "Lanches" },
    { t: "Sopa de {a} com {b}", c: "Sopas" },
  ];
  const a = pick(["alho", "limão", "mostarda", "queijo", "tomate", "mel", "iogurte", "ervas", "pimenta"]);
  const b = pick(["batata", "cenoura", "feijão", "abóbora", "milho", "cogumelos"]);
  const base = pick(bases);
  const title = base.t.replace("{a}", a).replace("{b}", b);
  const category = base.c || pick(categories);

  const ingredientsPool = {
    Massa: ["macarrão", "manteiga", "alho", "creme de leite", "parmesão", "sal", "pimenta", "azeite", "limão"],
    Frango: ["frango", "alho", "mel", "shoyu", "azeite", "limão", "mostarda", "sal", "pimenta"],
    Doces: ["farinha", "açúcar", "ovo", "leite", "fermento", "cacau", "manteiga", "baunilha"],
    Lanches: ["pão", "queijo", "presunto", "tomate", "orégano", "manteiga", "maionese"],
    Sopas: ["caldo", "batata", "cenoura", "cebola", "alho", "sal", "pimenta", "creme de leite"],
    Vegetariano: ["grão-de-bico", "tomate", "cebola", "alho", "azeite", "limão", "ervas", "sal", "pimenta"],
    Carne: ["carne", "cebola", "alho", "azeite", "sal", "pimenta", "molho barbecue", "mostarda"],
    Peixe: ["peixe", "limão", "alho", "azeite", "sal", "pimenta", "ervas"],
    "Café da manhã": ["ovo", "pão", "queijo", "leite", "banana", "aveia", "mel", "canela"],
  } as const;

  const pool = (ingredientsPool as any)[category] ?? ["ingrediente 1","ingrediente 2","ingrediente 3","ingrediente 4","ingrediente 5"];
  const ingredients = Array.from({length:5}, () => pick(pool))
    .filter((v, i, arr) => arr.indexOf(v) === i)
  while (ingredients.length < 5) ingredients.push(pick(pool));

  const steps = [
    "Separe e prepare os ingredientes (corte/ralar o que precisar).",
    "Aqueça uma panela/frigideira com um fio de azeite ou manteiga.",
    "Adicione o ingrediente principal e cozinhe até ficar no ponto.",
    "Ajuste com temperos e finalize com o toque do dia (queijo, limão, ervas, etc.).",
    "Sirva quente. Se quiser, acompanhe com salada ou arroz."
  ];

  return { title, category, ingredients, steps };
}

async function createUniqueSlug(title: string) {
  let base = slugify(title);
  if (!base) base = "receita";
  let slug = base;
  for (let i = 1; i < 200; i++) {
    const exists = await prisma.recipe.findUnique({ where: { slug } });
    if (!exists) return slug;
    slug = `${base}-${i}`;
  }
  return `${base}-${Date.now()}`;
}

export async function GET(req: Request) {
  const auth = req.headers.get("authorization") ?? "";
  const expected = process.env.CRON_SECRET ?? "";

  if (!expected) {
    return NextResponse.json({ ok: false, error: "CRON_SECRET não configurado" }, { status: 500 });
  }
  if (auth !== `Bearer ${expected}`) {
    return NextResponse.json({ ok: false, error: "Não autorizado" }, { status: 401 });
  }

  const url = new URL(req.url);
  const n = Math.min(Math.max(Number(url.searchParams.get("n") ?? "6"), 1), 30);

  const created: any[] = [];
  for (let i = 0; i < n; i++) {
    const gen = generateRecipe();
    const slug = await createUniqueSlug(gen.title);

    const r = await prisma.recipe.create({
      data: {
        title: gen.title,
        category: gen.category,
        slug,
        ingredients: JSON.stringify(gen.ingredients),
        steps: JSON.stringify(gen.steps),
      }
    });
    created.push({ id: r.id, title: r.title, slug: r.slug });
  }

  return NextResponse.json({ ok: true, createdCount: created.length, created });
}
