import Link from "next/link";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function CategoriesPage() {
  const categories = await prisma.recipe.groupBy({
    by: ["category"],
    _count: { category: true },
    orderBy: { _count: { category: "desc" } },
  });

  return (
    <div className="hero">
      <h1>Categorias</h1>
      <p>Explore por categoria.</p>
      <div className="kpis" style={{marginTop:14}}>
        {categories.map((c) => (
          <Link key={c.category} className="pill" href={`/categories/${encodeURIComponent(c.category)}`}>
            {c.category} ({c._count.category})
          </Link>
        ))}
      </div>
    </div>
  );
}
