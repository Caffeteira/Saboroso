import Link from "next/link";

export function Nav() {
  const name = process.env.SITE_NAME ?? "Receitas da Casa";
  return (
    <div className="nav">
      <Link href="/" className="brand">
        <b>{name}</b>
        <span>Receitas novas todos os dias (automático)</span>
      </Link>
      <div style={{display:"flex", gap:10, flexWrap:"wrap"}}>
        <Link className="btn" href="/categories">Categorias</Link>
        <Link className="btn" href="/admin">Admin</Link>
      </div>
    </div>
  );
}
