import { cookies } from "next/headers";
import { serialize } from "cookie";

const COOKIE_NAME = "admin_session";

export function isAdmin(): boolean {
  const c = cookies().get(COOKIE_NAME)?.value;
  return c === "1";
}

export function makeAdminCookie(): string {
  return serialize(COOKIE_NAME, "1", {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7, // 7 days
  });
}

export function clearAdminCookie(): string {
  return serialize(COOKIE_NAME, "0", {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 0,
  });
}
