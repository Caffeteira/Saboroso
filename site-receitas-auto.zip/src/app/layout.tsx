import "./globals.css";
import { Nav } from "@/components/Nav";

export const metadata = {
  title: "Receitas",
  description: "Receitas novas todos os dias",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-br">
      <body>
        <div className="container">
          <Nav />
          {children}
          <div className="footer">
            Dica: você pode automatizar a postagem diária com um cron chamando <code>/api/cron/daily</code>.
          </div>
        </div>
      </body>
    </html>
  );
}
