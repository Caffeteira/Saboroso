import { prisma } from "@/lib/prisma";
import { safeJsonParse } from "@/lib/text";
import Link from "next/link";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function RecipePage({ params }: { params: { slug: string } }) {
  const recipe = await prisma.recipe.findUnique({ where: { slug: params.slug } });
  if (!recipe) return notFound();

  const ingredients = safeJsonParse<string[]>(recipe.ingredients, []);
  const steps = safeJsonParse<string[]>(recipe.steps, []);

  return (
    <article>
      <div className="meta">
        <span className="badge">{recipe.category}</span>
        <span>Publicado em {new Date(recipe.publishedAt).toLocaleDateString("pt-BR")}</span>
      </div>
      <h1>{recipe.title}</h1>

      {recipe.imageUrl ? (
        <>
          <hr />
          <p className="meta">Imagem: <a href={recipe.imageUrl} target="_blank" rel="noreferrer">{recipe.imageUrl}</a></p>
        </>
      ) : null}

      <h2>Ingredientes</h2>
      <ul>
        {ingredients.map((i, idx) => <li key={idx}>{i}</li>)}
      </ul>

      <h2>Modo de preparo</h2>
      <ol>
        {steps.map((s, idx) => <li key={idx}>{s}</li>)}
      </ol>

      <hr />
      <div style={{display:"flex", gap:10, flexWrap:"wrap"}}>
        <Link className="btn" href="/">← Voltar</Link>
        <Link className="btn" href={`/categories/${encodeURIComponent(recipe.category)}`}>Mais de {recipe.category}</Link>
      </div>
    </article>
  );
}
