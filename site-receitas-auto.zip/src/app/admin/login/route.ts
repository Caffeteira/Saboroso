import { NextResponse } from "next/server";
import { makeAdminCookie } from "@/lib/auth";

export async function POST(req: Request) {
  const form = await req.formData();
  const password = String(form.get("password") ?? "");
  const expected = process.env.ADMIN_PASSWORD ?? "";

  if (!expected || password !== expected) {
    return NextResponse.redirect(new URL("/admin/login?err=1", req.url));
  }

  const res = NextResponse.redirect(new URL("/admin", req.url));
  res.headers.set("Set-Cookie", makeAdminCookie());
  return res;
}
