import Link from "next/link";

export type RecipeCardProps = {
  title: string;
  slug: string;
  category: string;
  publishedAt: string;
};

export function RecipeCard({ title, slug, category, publishedAt }: RecipeCardProps) {
  return (
    <Link href={`/recipe/${slug}`} className="card">
      <div className="meta">
        <span className="badge">{category}</span>
        <span>{new Date(publishedAt).toLocaleDateString("pt-BR")}</span>
      </div>
      <h3>{title}</h3>
      <div className="meta">
        <span>Ver receita →</span>
      </div>
    </Link>
  );
}
