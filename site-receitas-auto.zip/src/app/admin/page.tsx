import Link from "next/link";
import { isAdmin } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function AdminHome() {
  const admin = isAdmin();
  const recent = await prisma.recipe.findMany({ orderBy: { publishedAt: "desc" }, take: 10 });

  return (
    <>
      <div className="hero">
        <h1>Admin</h1>
        <p>Área simples para criar receitas manualmente e testar o cron.</p>

        <div className="kpis">
          {!admin ? (
            <Link className="pill" href="/admin/login">Fazer login</Link>
          ) : (
            <>
              <Link className="pill" href="/admin/new">Criar receita</Link>
              <form action="/admin/logout" method="post">
                <button className="pill" type="submit" style={{cursor:"pointer"}}>Sair</button>
              </form>
            </>
          )}
          <Link className="pill" href="/api/cron/daily" title="Precisa do header Authorization">Endpoint cron</Link>
        </div>
      </div>

      <div className="grid">
        {recent.map((r) => (
          <Link key={r.id} href={`/recipe/${r.slug}`} className="card">
            <div className="meta">
              <span className="badge">{r.category}</span>
              <span>{new Date(r.publishedAt).toLocaleDateString("pt-BR")}</span>
            </div>
            <h3>{r.title}</h3>
            <div className="meta"><span>{r.slug}</span></div>
          </Link>
        ))}
      </div>
    </>
  );
}
